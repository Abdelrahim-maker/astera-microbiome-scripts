# Astera soil microbiome data and analysis code

Manuscript: https://doi.org/10.5281/zenodo.23683684

Sequencing data and analysis code, Version 2.0.0: https://doi.org/10.5281/zenodo.23603407

Start with [github_upload/README.md](github_upload/README.md) and the [reproducibility audit](github_upload/REPRODUCIBILITY.md). Publication and licensing details were supplied by the project owner; DOI records could not be independently retrieved during this audit.

The focused Python workflow was rerun from local release archives and matched eight local manuscript reference tables. Balanced beta/network analyses ran but differed from historical summaries. MaAsLin2 remains unverified because its dependency is missing; raw-read provenance remains incomplete. Consult the audit for exact scope and evidence.

Manuscript/supplement: CC BY 4.0. Sequencing data/sample metadata: CC0 1.0. Project-authored scripts: [MIT](github_upload/LICENSE). Older releases and third-party materials retain their applicable licenses.

Historical repository folders describe earlier workflows. Use `github_upload/` for the focused scope.
