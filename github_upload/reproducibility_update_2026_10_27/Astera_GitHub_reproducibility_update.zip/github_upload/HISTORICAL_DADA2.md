# Historical raw-read workflow audit

Status: **Historical workflow incomplete**. Inspected the preserved `denosing.zip`; no raw-read analysis was rerun. Script contents identify candidate settings, not proof of which variant generated final deposited tables.

| Script | Observed settings / inputs | Unresolved provenance |
| --- | --- | --- |
| `denoising.sh` | QIIME2 paired denoising; input `16S_2_cs_pairedend_sequences.qza`; truncation 142/151; outputs `table_2.qza`, `rep_seqs_2.qza`, `denoising_demux_stats_2.qza` | Raw FASTQ import and primer-removal lineage to the final table not verified |
| `final_dada2_post_asv_script.R` | Alternative 16S R workflow: truncLen 148/148; maxEE 2/5; maxN 0; truncQ 2; rm.phix FALSE; SILVA filename `silva_nr99_v138.1_train_set.fa.gz` | Different settings from QIIME2 variant; exact executed variant and reference checksum unresolved |
| `ITS_dada.R` | Inputs explicitly post-Cutadapt; maxEE 2/2; reference filename `sh_general_release_dynamic_18.07.2023_dev.fasta` | Primer sequences and exact Cutadapt command/settings not established; database filename is not a verified checksum |
| `ITS_asv_post_asv.R` | maxEE 2/2; maxN 0; truncQ 2; minLen 50; rm.phix FALSE; includes SILVA reference path | Conflicting taxonomy reference versus ITS_dada.R; cannot treat both as a single validated workflow |
| `dada2_amf.R` | truncLen 270/255; trimLeft 10; maxEE 2/2; maxN 0; truncQ 2; rm.phix FALSE; `maarjam_seqsdb.fasta` | Database release/checksum unspecified; final count-table lineage unverified |

Historical files retain absolute OSC paths, external library/reference dependencies, and interactive code. Preserve them unchanged. A complete rerun requires a sample-to-FASTQ manifest through primer trimming, selected script versions, software versions, database checksums, read-tracking outputs, and a comparison of final ASV sequences/counts/taxonomy with deposited source data. Do not infer missing parameters from manuscript results.
