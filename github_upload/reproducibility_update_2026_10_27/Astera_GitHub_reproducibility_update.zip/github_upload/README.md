# Astera sequencing data and analysis code

Source data and code for the Astera Hidden Science soil microbiome study.

## Published research outputs

- Manuscript: https://doi.org/10.5281/zenodo.23683684
- Sequencing data and analysis code, Version 2.0.0: https://doi.org/10.5281/zenodo.23603407

The manuscript and dataset were publicly released in October 2026, according to the publication information supplied by the project owner. The DOI records could not be independently retrieved during this audit.

## Run and verify

Extract `Astera_source_data.zip` into this directory so that `data/` and `source/` share the same root. Preserve the original release archives. Use Python 3.9 and the recorded dependencies:

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -r environment/requirements-python-validated.txt
python source/run_retained_checks.py
python source/compare_reproduction.py --report reproduced/comparison.json
```

On Windows, activate with `.venv\Scripts\Activate.ps1`. The fresh dependency installation is not verified; the analyses were executed with the existing recorded Python environment.

The Python runner writes rarefaction, whole-profile restricted management PERMANOVA, and six marker-specific association networks under `reproduced/`. On 27 October 2026, eight output tables matched the local retained manuscript tables. See [REPRODUCIBILITY.md](REPRODUCIBILITY.md) for exact scope, commands, evidence, and remaining gaps. Reference CSVs are included under `verification/reference/` specifically for comparison; these are additional review materials, not files claimed to be in the published Version 2.0.0 code archive.

The source-data archive contains counts, representative sequences, taxonomy, and sample metadata. Raw FASTQ archives and `denosing.zip` are separate. No complete raw-read-to-manuscript reproduction is claimed.

## Licensing

- Manuscript and supplementary material: CC BY 4.0.
- Sequencing data and sample metadata: CC0 1.0.
- Project-authored analysis scripts: [MIT License](LICENSE).

These publication licensing details were supplied by the project owner. Third-party materials retain their licenses; this update does not relicense older releases.

## Interpretation

Management and collection date are confounded. Profiles do not establish farm-level independence. Networks describe associations, not demonstrated interactions. Carbon, cross-marker, and date-effect analyses are outside this focused workflow.
