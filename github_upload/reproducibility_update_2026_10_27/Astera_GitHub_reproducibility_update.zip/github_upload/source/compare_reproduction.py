"""Compare newly generated outputs with explicitly identified local manuscript tables."""
from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
p = argparse.ArgumentParser()
p.add_argument('--run-root', type=Path, default=Path(__file__).resolve().parents[1])
p.add_argument('--reference-root', type=Path, default=Path(__file__).resolve().parents[1]/'verification/reference')
p.add_argument('--report', type=Path, default=Path('comparison.json'))
a = p.parse_args()
pairs = {
 'Table2_alpha.csv': 'rarefied/audit/alpha_tests_with_BH.csv',
 'Table3_beta_restricted.csv': 'restricted_permanova/model_statistics.csv',
 'S4_network_metrics.csv': 'network_edges/network_summary.csv',
 'alpha_all_scenarios.csv': 'rarefied/rarefaction/alpha_tests_rarefied.csv',
 'depth_selection.csv': 'rarefied/rarefaction/depth_selection.csv',
 'unique_ASV_retention_summary.csv': 'rarefied/rarefaction/unique_ASV_retention_summary.csv',
 'per_draw_test_summary.csv': 'rarefied/rarefaction/per_draw_test_summary.csv',
 'sample_alpha_rarefied.csv': 'rarefied/rarefaction/sample_alpha_rarefied.csv',
}
rows=[]
for reference, output in pairs.items():
 try:
  expected=pd.read_csv(a.reference_root/reference)
  actual=pd.read_csv(a.run_root/'reproduced'/output)
  pd.testing.assert_frame_equal(actual, expected, check_dtype=False, check_exact=False, rtol=1e-10, atol=1e-12)
  rows.append(dict(reference=reference, output=output, status='Verified', rows=len(actual)))
 except (AssertionError, OSError, ValueError) as e:
  rows.append(dict(reference=reference, output=output, status='Runs but differs' if isinstance(e,AssertionError) else 'Not yet tested', detail=str(e)))
a.report.parent.mkdir(parents=True,exist_ok=True)
a.report.write_text(json.dumps(dict(rtol=1e-10,atol=1e-12,comparisons=rows),indent=2)+'\n')
for row in rows: print(row['reference'],row['status'])
raise SystemExit(0 if all(r['status']=='Verified' for r in rows) else 1)
